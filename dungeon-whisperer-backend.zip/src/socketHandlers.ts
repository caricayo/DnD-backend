// Socket event handlers
