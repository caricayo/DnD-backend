// Dice roller util
