// Session state machine
