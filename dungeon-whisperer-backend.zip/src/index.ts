// Express + Socket.IO backend entry
